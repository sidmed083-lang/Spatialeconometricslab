"""Tests for the NumPy/SciPy-only helpers behind the autocorrelation statistics."""

import numpy as np
import pytest

from spatial_econometrics.statistics._common import (
    NOT_SIGNIFICANT,
    StatisticsError,
    adjust_pvalues,
    check_alpha,
    classify_quadrants,
    collect_warnings,
    decide_global,
    p_from_z,
    prepare_variable,
    pseudo_p_two_sided,
    quadrant_codes,
    seeded,
)


def test_pseudo_p_two_sided_extremes():
    sim = np.linspace(-1, 1, 999)
    assert pseudo_p_two_sided(2.0, sim) == pytest.approx(1 / 1000)
    assert pseudo_p_two_sided(-2.0, sim) == pytest.approx(1 / 1000)
    assert pseudo_p_two_sided(0.0, sim) >= 0.998


def test_pseudo_p_two_sided_matrix_matches_vector():
    rng = np.random.default_rng(0)
    sim = rng.normal(size=(5, 499))
    obs = np.array([0.1, 2.5, -10.0, 0.0, 1.0])
    vec = pseudo_p_two_sided(obs, sim)
    assert vec.shape == (5,)
    for i in range(5):
        assert vec[i] == pytest.approx(pseudo_p_two_sided(obs[i], sim[i]))
    assert vec[2] == pytest.approx(1 / 500)


def test_p_from_z():
    assert p_from_z(0.0) == pytest.approx(1.0)
    assert p_from_z(1.96) == pytest.approx(0.05, abs=1e-3)
    assert p_from_z(-1.96) == pytest.approx(p_from_z(1.96))


def test_adjust_pvalues():
    p = np.array([0.01, 0.02, 0.03, 0.04, 0.05])
    assert np.allclose(adjust_pvalues(p, "none"), p)
    assert np.allclose(adjust_pvalues(p, "bonferroni"), [0.05, 0.10, 0.15, 0.20, 0.25])
    assert np.allclose(adjust_pvalues(p, "fdr_bh"), [0.05] * 5)
    shuffled = np.array([0.04, 0.01, 0.9, 0.03])
    bh = adjust_pvalues(shuffled, "fdr_bh")
    assert (bh >= shuffled).all() and (bh <= 1).all()
    # sorted p = .01,.03,.04,.9 -> p*m/rank = .04,.06,.0533,.9 -> monotone: .04,.0533,.0533,.9
    assert np.allclose(bh, [0.16 / 3, 0.04, 0.9, 0.16 / 3])
    with pytest.raises(StatisticsError):
        adjust_pvalues(p, "holm")


def test_quadrants_and_labels():
    z = np.array([1.0, -1.0, -1.0, 1.0])
    lag = np.array([1.0, 1.0, -1.0, -1.0])
    q = quadrant_codes(z, lag)
    assert q.tolist() == [1, 2, 3, 4]
    p = np.array([0.01, 0.2, 0.04, 0.5])
    labels = classify_quadrants(q, p, 0.05)
    assert labels.tolist() == ["High-High", NOT_SIGNIFICANT, "Low-Low", NOT_SIGNIFICANT]


def test_prepare_variable_validation():
    assert prepare_variable([1, 2, 3], 3).dtype == float
    with pytest.raises(StatisticsError, match="values but"):
        prepare_variable([1, 2, 3], 4)
    with pytest.raises(StatisticsError, match="missing"):
        prepare_variable([1, np.nan, 3], 3)
    with pytest.raises(StatisticsError, match="constant"):
        prepare_variable([2, 2, 2], 3)
    with pytest.raises(StatisticsError, match="negative"):
        prepare_variable([1, -2, 3], 3, nonnegative=True)
    with pytest.raises(StatisticsError):
        check_alpha(1.5)


def test_seeded_is_reproducible_and_restores_state():
    np.random.seed(123)
    before = np.random.get_state()[1].copy()
    with seeded(7):
        a = np.random.rand(3)
    with seeded(7):
        b = np.random.rand(3)
    assert np.array_equal(a, b)
    assert np.array_equal(np.random.get_state()[1], before)


def test_decide_global_directions_and_basis():
    kw = dict(name="Moran's", symbol="I", expected=-0.01, alpha=0.05)
    inf, p, sig, direction, text = decide_global(
        statistic=0.4, p_normal=0.5, p_sim=0.001, permutations=999, positive_if_above=True, **kw
    )
    assert (inf, sig, direction) == ("permutation", True, "positive") and p == 0.001
    assert "positive spatial autocorrelation" in text and "999 permutations" in text

    inf, p, sig, direction, _ = decide_global(
        statistic=-0.4, p_normal=0.01, p_sim=None, permutations=0, positive_if_above=True, **kw
    )
    assert (inf, sig, direction) == ("normal approximation", True, "negative")

    # Geary: C below its expectation of 1 means *positive* autocorrelation
    _, _, sig, direction, _ = decide_global(
        name="Geary's", symbol="C", statistic=0.6, expected=1.0, p_normal=0.9, p_sim=0.002,
        permutations=999, alpha=0.05, positive_if_above=False,
    )
    assert sig and direction == "positive"

    _, _, sig, direction, text = decide_global(
        statistic=0.01, p_normal=0.5, p_sim=0.4, permutations=999, positive_if_above=True, **kw
    )
    assert not sig and direction == "none" and "no statistically significant" in text


class _FakeW:
    islands = [3, 4]


def test_collect_warnings():
    notes = collect_warnings(_FakeW(), n=20, permutations=19, local=True)
    joined = " ".join(notes)
    assert "2 island" in joined and "30 observations" in joined
    assert "19 permutations" in joined and "FDR" in joined
    assert collect_warnings(type("W", (), {"islands": []})(), 100, 999) == ()
