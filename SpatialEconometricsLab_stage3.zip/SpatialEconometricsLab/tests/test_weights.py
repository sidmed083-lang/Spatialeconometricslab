import geopandas as gpd
import numpy as np
import pytest
from shapely.geometry import Point

from spatial_econometrics.data import make_lattice
from spatial_econometrics.weights import (
    WeightsConfig,
    WeightsError,
    build_weights,
    build_weights_without_islands,
    cardinality_table,
    require_no_islands,
    suggest_distance_threshold,
    validate_weights,
    weights_summary,
    weights_to_edges,
)


def test_rook_and_queen_neighbour_counts(lattice):
    rook = weights_summary(build_weights(lattice, kind="rook"))
    queen = weights_summary(build_weights(lattice, kind="queen"))
    assert (rook["min_neighbors"], rook["max_neighbors"]) == (2, 4)
    assert (queen["min_neighbors"], queen["max_neighbors"]) == (3, 8)
    assert rook["n_islands"] == 0 and rook["n_components"] == 1
    assert rook["is_symmetric_structure"] and rook["transform"] == "R"


def test_row_standardised_and_binary_transforms(lattice):
    w_r = build_weights(lattice, kind="rook", transform="R")
    assert np.allclose(np.asarray(w_r.sparse.sum(axis=1)).ravel(), 1.0)
    w_b = build_weights(lattice, kind="rook", transform="B")
    assert set(np.unique(w_b.sparse.data)) == {1.0}


def test_knn_has_exactly_k_neighbours(lattice):
    summary = weights_summary(build_weights(lattice, kind="knn", k=3))
    assert summary["min_neighbors"] == summary["max_neighbors"] == 3


def test_distance_band_matches_rook_on_unit_lattice(lattice):
    w = build_weights(lattice, kind="distance", threshold=1001.0)
    rook = build_weights(lattice, kind="rook")
    assert weights_summary(w)["max_neighbors"] == 4
    assert (w.sparse != 0).nnz == (rook.sparse != 0).nnz


def test_suggest_distance_threshold(lattice):
    assert suggest_distance_threshold(lattice) == pytest.approx(1000.0, rel=1e-6)
    w = build_weights(lattice, kind="distance")  # auto threshold
    assert weights_summary(w)["n_islands"] == 0


def test_config_description_and_validation():
    assert "Queen" in WeightsConfig(kind="queen").describe()
    assert "4 nearest" in WeightsConfig(kind="knn", k=4).describe()
    for bad in (
        dict(kind="bogus"),
        dict(transform="X"),
        dict(k=0),
        dict(threshold=-1.0),
        dict(alpha=0.5),
    ):
        with pytest.raises(WeightsError):
            WeightsConfig(**bad)
    with pytest.raises(WeightsError):
        build_weights(make_lattice(3, 3), WeightsConfig(), kind="rook")


def test_contiguity_requires_polygons(points):
    projected = points.to_crs("EPSG:32631")
    with pytest.raises(WeightsError, match="polygon"):
        build_weights(projected, kind="queen")


def test_geographic_crs_blocked_for_distance_weights(points):
    with pytest.raises(WeightsError, match="projected"):
        build_weights(points, kind="knn", k=1)
    assert build_weights(points, kind="knn", k=1, allow_geographic=True).n == 3


def test_knn_k_must_be_smaller_than_n(lattice):
    with pytest.raises(WeightsError, match="smaller"):
        build_weights(lattice, kind="knn", k=16)


@pytest.fixture
def points_with_outlier():
    coords = [(0, 0), (10, 0), (0, 10), (10, 10), (5, 5), (1000, 1000)]
    return gpd.GeoDataFrame(
        {"v": range(6)}, geometry=[Point(p) for p in coords], crs="EPSG:32631"
    )


def test_islands_are_reported_and_can_be_dropped(points_with_outlier):
    cfg = WeightsConfig(kind="distance", threshold=20.0)
    w = build_weights(points_with_outlier, cfg)
    assert weights_summary(w)["islands"] == [5]
    with pytest.raises(WeightsError, match="island"):
        require_no_islands(w)

    subset, w2, dropped = build_weights_without_islands(points_with_outlier, cfg)
    assert dropped == [5] and len(subset) == 5 and w2.n == 5
    require_no_islands(w2)


def test_summary_of_weights_with_island(points_with_outlier):
    w = build_weights(points_with_outlier, kind="distance", threshold=20.0)
    s = weights_summary(w)
    assert s["n_islands"] == 1 and s["min_neighbors"] == 0 and s["n_components"] == 2


def test_cardinality_table_and_edges():
    grid = make_lattice(3, 3)
    w = build_weights(grid, kind="rook")
    table = cardinality_table(w)
    assert table["n_neighbors"].tolist() == [2, 3, 2, 3, 4, 3, 2, 3, 2]
    edges = weights_to_edges(grid, w)
    assert len(edges) == 12  # 6 horizontal + 6 vertical links
    assert edges.crs.to_epsg() == 32631
    assert (edges["i"] < edges["j"]).all()


def test_validate_weights_detects_size_mismatch(lattice):
    w = build_weights(lattice, kind="rook")
    validate_weights(w, 16)
    with pytest.raises(WeightsError):
        validate_weights(w, 15)
