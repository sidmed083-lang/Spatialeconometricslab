import numpy as np
import pandas as pd
import pytest

from spatial_econometrics.data import lattice_weights_matrix, make_lattice
from spatial_econometrics.statistics import (
    StatisticsError,
    geary_global,
    getis_ord_gi_star,
    local_moran,
    moran_global,
    moran_scatter_data,
)
from spatial_econometrics.weights import build_weights

N = 10


@pytest.fixture(scope="module")
def grid():
    return make_lattice(N, N)


@pytest.fixture(scope="module")
def w(grid):
    return build_weights(grid, kind="rook")


@pytest.fixture(scope="module")
def gradient(grid):
    return (grid["row"] + grid["col"]).to_numpy(dtype=float)


@pytest.fixture(scope="module")
def checkerboard(grid):
    return ((grid["row"] + grid["col"]) % 2).to_numpy(dtype=float)


def _manual_moran(y, W):
    z = y - y.mean()
    return len(y) / W.sum() * (z @ W @ z) / (z @ z)


def _manual_geary(y, W):
    diff2 = (y[:, None] - y[None, :]) ** 2
    return (len(y) - 1) * (W * diff2).sum() / (2 * W.sum() * ((y - y.mean()) ** 2).sum())


def test_moran_matches_closed_form(w):
    y = np.random.default_rng(3).normal(size=N * N)
    W = lattice_weights_matrix(N, N)
    res = moran_global(y, w, permutations=99)
    assert res.statistic == pytest.approx(_manual_moran(y, W), abs=1e-10)
    assert res.expected == pytest.approx(-1 / (N * N - 1))


def test_geary_matches_closed_form(w):
    y = np.random.default_rng(4).normal(size=N * N)
    W = lattice_weights_matrix(N, N)
    assert geary_global(y, w, permutations=99).statistic == pytest.approx(
        _manual_geary(y, W), abs=1e-10
    )


def test_gradient_is_positively_autocorrelated(w, gradient):
    moran = moran_global(gradient, w)
    assert moran.statistic > 0.7
    assert moran.significant and moran.direction == "positive"
    assert moran.p_sim == pytest.approx(1 / 1000)
    assert "positive spatial autocorrelation" in moran.interpretation
    geary = geary_global(gradient, w)
    assert geary.statistic < 1 and geary.direction == "positive"


def test_checkerboard_is_perfectly_negative(w, checkerboard):
    moran = moran_global(checkerboard, w)
    assert moran.statistic == pytest.approx(-1.0, abs=1e-8)
    assert moran.direction == "negative"
    geary = geary_global(checkerboard, w)
    assert geary.statistic == pytest.approx(1.98, abs=1e-8) and geary.direction == "negative"


def test_random_noise_has_small_statistic(w):
    y = np.random.default_rng(0).normal(size=N * N)
    assert abs(moran_global(y, w).statistic) < 0.2


def test_permutation_inference_is_reproducible(w):
    y = np.random.default_rng(1).normal(size=N * N)
    a = moran_global(y, w, permutations=199, seed=5)
    b = moran_global(y, w, permutations=199, seed=5)
    assert a.p_sim == b.p_sim and a.z_sim == b.z_sim


def test_no_permutations_uses_normal_approximation(w, gradient):
    res = moran_global(gradient, w, permutations=0)
    assert res.p_sim is None and res.inference == "normal approximation"
    assert res.p_value == res.p_normal
    assert not moran_global(gradient, w, permutations=0).to_frame().empty


def test_global_does_not_mutate_weights(grid, gradient):
    w = build_weights(grid, kind="queen", transform="B")
    moran_global(gradient, w, permutations=19)
    assert w.transform == "B"


def test_input_validation(w, gradient):
    with pytest.raises(StatisticsError):
        moran_global(gradient[:-1], w)
    with pytest.raises(StatisticsError):
        moran_global(np.ones(N * N), w)
    with pytest.raises(StatisticsError):
        moran_global(gradient, w, alpha=2.0)


def test_moran_scatter_slope_equals_moran_i(w, gradient):
    data = moran_scatter_data(gradient, w)
    slope = (data["z"] @ data["lag_z"]) / (data["z"] @ data["z"])
    assert slope == pytest.approx(moran_global(gradient, w, permutations=0).statistic)
    assert set(data["quadrant"]) <= {1, 2, 3, 4}
    assert list(data.columns) == ["z", "lag_z", "quadrant", "quadrant_label"]


def test_local_moran_structure_and_quadrants(w, gradient):
    res = local_moran(gradient, w, permutations=499)
    t = res.table
    assert len(t) == N * N and t.index.tolist() == list(range(N * N))
    assert t.loc[N * N - 1, "quadrant"] == 1  # highest corner: High-High
    assert t.loc[0, "quadrant"] == 3  # lowest corner: Low-Low
    positive_local = t["local_i"] > 0
    assert (positive_local == t["quadrant"].isin([1, 3])).all()
    assert t["p_value"].between(0, 1).all()
    assert sum(res.summary.values()) == N * N
    assert "Local statistics are exploratory" in res.interpretation


def test_local_moran_reproducible_and_adjusted(w, gradient):
    a = local_moran(gradient, w, permutations=199, seed=9, p_adjust="fdr_bh")
    b = local_moran(gradient, w, permutations=199, seed=9, p_adjust="fdr_bh")
    pd.testing.assert_frame_equal(a.table, b.table)
    assert (a.table["p_adjusted"] >= a.table["p_value"] - 1e-12).all()
    with pytest.raises(StatisticsError):
        local_moran(gradient, w, permutations=0)
    with pytest.raises(StatisticsError):
        local_moran(gradient, w, p_adjust="holm")


def test_gi_star_finds_planted_hot_spot(grid, w):
    rng = np.random.default_rng(2)
    y = 1.0 + rng.normal(scale=0.1, size=N * N)
    block = (grid["row"].between(3, 5) & grid["col"].between(3, 5)).to_numpy()
    y[block] = 10.0
    res = getis_ord_gi_star(y, w, permutations=999)
    center = 4 * N + 4
    assert res.table.loc[center, "z"] > 3
    assert res.table.loc[center, "cluster"] == "Hot spot"
    assert res.summary["Hot spot"] >= 1
    assert set(res.table["cluster"]) <= {"Hot spot", "Cold spot", "Not significant"}


def test_gi_star_requires_non_negative_values(w, gradient):
    with pytest.raises(StatisticsError, match="negative"):
        getis_ord_gi_star(gradient - 5.0, w)
