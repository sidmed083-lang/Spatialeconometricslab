"""SpatialEconometricsLab: spatial econometrics and GIS analysis toolkit."""

__version__ = "0.1.0"
