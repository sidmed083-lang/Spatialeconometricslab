"""Local Moran's I (LISA): clusters (HH, LL) and spatial outliers (HL, LH)."""

from __future__ import annotations

import copy

import numpy as np
import pandas as pd
from esda import Moran_Local
from libpysal.weights import W

from ..weights.diagnostics import validate_weights
from ._common import (
    NOT_SIGNIFICANT,
    QUADRANT_LABELS,
    LocalResult,
    StatisticsError,
    adjust_pvalues,
    call_esda,
    check_alpha,
    classify_quadrants,
    collect_warnings,
    prepare_variable,
    pseudo_p_two_sided,
    quadrant_codes,
)


def local_moran(
    y,
    w: W,
    *,
    permutations: int = 999,
    seed: int | None = 42,
    alpha: float = 0.05,
    p_adjust: str = "none",
    transformation: str = "r",
) -> LocalResult:
    """Local Moran's I with conditional-permutation inference.

    The result table (positional index, aligned with the input rows) has the local
    statistic, the standardised value and its spatial lag, the quadrant, the two-sided
    pseudo p-value (``p_value``), its adjusted version (``p_adjusted``, per ``p_adjust``),
    esda's own one-sided pseudo p-value for comparison, and a ``cluster`` label:
    High-High / Low-Low (clusters), High-Low / Low-High (spatial outliers), or
    "Not significant" when ``p_adjusted >= alpha``.
    """
    check_alpha(alpha)
    if permutations < 1:
        raise StatisticsError("Local Moran's I needs permutations > 0 for inference.")
    validate_weights(w, w.n)
    yv = prepare_variable(y, w.n)

    lm = call_esda(
        Moran_Local, yv, copy.deepcopy(w), seed=seed, transformation=transformation,
        permutations=permutations,
    )
    notes = list(collect_warnings(w, w.n, permutations, local=True))
    sims = getattr(lm, "rlisas", None)
    if sims is not None:
        p_value = pseudo_p_two_sided(np.asarray(lm.Is), np.asarray(sims))
    else:
        p_value = np.asarray(lm.p_sim, dtype=float)
        notes.append("Permutation draws were not retained; p-values are esda's one-sided values.")

    wr = copy.deepcopy(w)
    wr.transform = "R"
    z = (yv - yv.mean()) / yv.std()
    lag_z = np.asarray(wr.sparse @ z).ravel()
    quadrant = quadrant_codes(z, lag_z)
    p_adjusted = adjust_pvalues(p_value, p_adjust)

    table = pd.DataFrame(
        {
            "local_i": np.asarray(lm.Is, dtype=float),
            "z": z,
            "lag_z": lag_z,
            "quadrant": quadrant,
            "p_value": p_value,
            "p_adjusted": p_adjusted,
            "p_esda_one_sided": np.asarray(lm.p_sim, dtype=float),
            "cluster": classify_quadrants(quadrant, p_adjusted, alpha),
        }
    )
    counts = table["cluster"].value_counts()
    labels = [*QUADRANT_LABELS.values(), NOT_SIGNIFICANT]
    summary = {label: int(counts.get(label, 0)) for label in labels}
    adj = "unadjusted" if p_adjust == "none" else f"{p_adjust}-adjusted"
    interpretation = (
        f"At alpha = {alpha} ({adj} two-sided pseudo p-values, {permutations} permutations): "
        f"{summary['High-High']} High-High and {summary['Low-Low']} Low-Low locations form "
        f"significant clusters; {summary['High-Low']} High-Low and {summary['Low-High']} "
        f"Low-High locations are significant spatial outliers; {summary[NOT_SIGNIFICANT]} "
        "are not significant. Local statistics are exploratory: they are correlated across "
        "neighbours and multiply tested."
    )
    return LocalResult(
        name="Local Moran's I", table=table, alpha=alpha, p_adjust=p_adjust,
        permutations=permutations, seed=seed, summary=summary,
        interpretation=interpretation, warnings=tuple(notes),
    )
