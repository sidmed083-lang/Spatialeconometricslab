"""Global Geary's C."""

from __future__ import annotations

import copy

import numpy as np
from esda import Geary
from libpysal.weights import W

from ..weights.diagnostics import validate_weights
from ._common import (
    GlobalResult,
    call_esda,
    check_alpha,
    collect_warnings,
    decide_global,
    p_from_z,
    prepare_variable,
    pseudo_p_two_sided,
)


def geary_global(
    y,
    w: W,
    *,
    permutations: int = 999,
    seed: int | None = 42,
    alpha: float = 0.05,
    transformation: str = "r",
) -> GlobalResult:
    """Global Geary's C. ``C < 1`` indicates positive and ``C > 1`` negative autocorrelation.

    Geary's C is more sensitive to local differences between neighbours than Moran's I.
    Reported p-values are two-sided; see :func:`spatial_econometrics.statistics.moran_global`.
    """
    check_alpha(alpha)
    validate_weights(w, w.n)
    yv = prepare_variable(y, w.n)
    g = call_esda(
        Geary, yv, copy.deepcopy(w), seed=seed, transformation=transformation,
        permutations=permutations,
    )
    p_sim = z_sim = None
    sim = getattr(g, "sim", None)
    if permutations > 0 and sim is not None:
        sim = np.asarray(sim)
        p_sim = pseudo_p_two_sided(g.C, sim)
        z_sim = float((g.C - sim.mean()) / sim.std())

    p_normal = float(p_from_z(g.z_norm))
    inference, p_value, significant, direction, text = decide_global(
        name="Geary's", symbol="C", statistic=float(g.C), expected=float(g.EC),
        p_normal=p_normal, p_sim=p_sim, permutations=permutations, alpha=alpha,
        positive_if_above=False,
    )
    return GlobalResult(
        name="Geary's", symbol="C", statistic=float(g.C), expected=float(g.EC),
        variance_normal=float(g.VC_norm), variance_randomization=float(g.VC_rand),
        z_normal=float(g.z_norm), z_randomization=float(g.z_rand), p_normal=p_normal,
        p_randomization=float(p_from_z(g.z_rand)), p_sim=p_sim, z_sim=z_sim,
        permutations=permutations, seed=seed, alpha=alpha, inference=inference,
        p_value=p_value, significant=significant, direction=direction, interpretation=text,
        warnings=collect_warnings(w, w.n, permutations),
    )
