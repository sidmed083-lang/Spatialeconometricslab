"""Global Moran's I and Moran scatterplot data."""

from __future__ import annotations

import copy

import numpy as np
import pandas as pd
from esda import Moran
from libpysal.weights import W

from ..weights.diagnostics import validate_weights
from ._common import (
    GlobalResult,
    call_esda,
    check_alpha,
    classify_quadrants,
    collect_warnings,
    decide_global,
    p_from_z,
    prepare_variable,
    pseudo_p_two_sided,
    quadrant_codes,
)


def moran_global(
    y,
    w: W,
    *,
    permutations: int = 999,
    seed: int | None = 42,
    alpha: float = 0.05,
    transformation: str = "r",
) -> GlobalResult:
    """Global Moran's I with analytical and permutation-based inference.

    Weights are row-standardised internally (``transformation="r"``) on a copy; the
    caller's weights are never modified. All reported p-values are two-sided. With
    ``permutations > 0`` the decision uses the permutation pseudo p-value; otherwise the
    normal approximation.
    """
    check_alpha(alpha)
    validate_weights(w, w.n)
    yv = prepare_variable(y, w.n)
    m = call_esda(
        Moran, yv, copy.deepcopy(w), seed=seed, transformation=transformation,
        permutations=permutations,
    )
    p_sim = z_sim = None
    sim = getattr(m, "sim", None)
    if permutations > 0 and sim is not None:
        sim = np.asarray(sim)
        p_sim = pseudo_p_two_sided(m.I, sim)
        z_sim = float((m.I - sim.mean()) / sim.std())

    p_normal = float(p_from_z(m.z_norm))
    inference, p_value, significant, direction, text = decide_global(
        name="Moran's", symbol="I", statistic=float(m.I), expected=float(m.EI),
        p_normal=p_normal, p_sim=p_sim, permutations=permutations, alpha=alpha,
        positive_if_above=True,
    )
    return GlobalResult(
        name="Moran's", symbol="I", statistic=float(m.I), expected=float(m.EI),
        variance_normal=float(m.VI_norm), variance_randomization=float(m.VI_rand),
        z_normal=float(m.z_norm), z_randomization=float(m.z_rand), p_normal=p_normal,
        p_randomization=float(p_from_z(m.z_rand)), p_sim=p_sim, z_sim=z_sim,
        permutations=permutations, seed=seed, alpha=alpha, inference=inference,
        p_value=p_value, significant=significant, direction=direction, interpretation=text,
        warnings=collect_warnings(w, w.n, permutations),
    )


def moran_scatter_data(y, w: W) -> pd.DataFrame:
    """Data for a Moran scatterplot: standardised ``y``, its spatial lag and the quadrant.

    The lag uses row-standardised weights, so the OLS slope of ``lag_z`` on ``z`` equals
    Moran's I.
    """
    validate_weights(w, w.n)
    yv = prepare_variable(y, w.n)
    wr = copy.deepcopy(w)
    wr.transform = "R"
    z = (yv - yv.mean()) / yv.std()
    lag_z = np.asarray(wr.sparse @ z).ravel()
    q = quadrant_codes(z, lag_z)
    return pd.DataFrame(
        {
            "z": z,
            "lag_z": lag_z,
            "quadrant": q,
            "quadrant_label": classify_quadrants(q, np.zeros(q.size), alpha=1.0),
        }
    )
