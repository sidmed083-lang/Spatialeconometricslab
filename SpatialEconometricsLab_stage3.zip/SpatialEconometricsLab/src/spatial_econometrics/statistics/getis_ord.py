"""Local Getis-Ord Gi* hot spot / cold spot analysis."""

from __future__ import annotations

import copy

import numpy as np
import pandas as pd
from esda import G_Local
from libpysal.weights import W

from ..weights.diagnostics import validate_weights
from ._common import (
    NOT_SIGNIFICANT,
    LocalResult,
    adjust_pvalues,
    call_esda,
    check_alpha,
    collect_warnings,
    p_from_z,
    prepare_variable,
    pseudo_p_two_sided,
)

HOT, COLD = "Hot spot", "Cold spot"


def getis_ord_gi_star(
    y,
    w: W,
    *,
    permutations: int = 999,
    seed: int | None = 42,
    alpha: float = 0.05,
    p_adjust: str = "none",
) -> LocalResult:
    """Getis-Ord Gi* (focal observation included in its own neighbourhood).

    Uses binary weights (``transform="B"``) as in Ord & Getis (1995). ``y`` must be
    non-negative. Cells with a significant positive z-score are hot spots (high values
    surrounded by high values) and significant negative z-scores are cold spots. Unlike
    Local Moran's I, Gi* cannot flag spatial outliers.
    """
    check_alpha(alpha)
    validate_weights(w, w.n)
    yv = prepare_variable(y, w.n, nonnegative=True)
    use_sim = permutations > 0

    lg = call_esda(
        G_Local, yv, copy.deepcopy(w), seed=seed, transform="B",
        permutations=permutations, star=True,
    )
    z = np.asarray(lg.Zs, dtype=float)
    p_normal = np.asarray(p_from_z(z), dtype=float)
    notes = list(collect_warnings(w, w.n, permutations, local=True))

    p_sim = None
    if use_sim:
        sims = getattr(lg, "rGs", None)
        if sims is not None:
            p_sim = pseudo_p_two_sided(np.asarray(lg.Gs), np.asarray(sims))
        else:
            p_sim = np.asarray(lg.p_sim, dtype=float)
            notes.append("Permutation draws were not retained; using esda's one-sided p-values.")
    p_value = p_sim if p_sim is not None else p_normal
    p_adjusted = adjust_pvalues(p_value, p_adjust)

    cluster = np.where(
        p_adjusted < alpha, np.where(z > 0, HOT, COLD), NOT_SIGNIFICANT
    ).astype(object)
    table = pd.DataFrame(
        {
            "gi_star": np.asarray(lg.Gs, dtype=float),
            "expected": np.asarray(lg.EGs, dtype=float),
            "variance": np.asarray(lg.VGs, dtype=float),
            "z": z,
            "p_normal": p_normal,
            "p_sim": p_sim if p_sim is not None else np.nan,
            "p_value": p_value,
            "p_adjusted": p_adjusted,
            "cluster": cluster,
        }
    )
    summary = {label: int((cluster == label).sum()) for label in (HOT, COLD, NOT_SIGNIFICANT)}
    basis = (
        f"{permutations}-permutation pseudo p-values"
        if use_sim
        else "normal-approximation p-values"
    )
    adj = "unadjusted" if p_adjust == "none" else f"{p_adjust}-adjusted"
    interpretation = (
        f"At alpha = {alpha} ({adj} two-sided {basis}): {summary[HOT]} hot spots, "
        f"{summary[COLD]} cold spots and {summary[NOT_SIGNIFICANT]} not significant. Hot spots "
        "are locations whose neighbourhood (including the location itself) has unusually high "
        "values relative to the study area; cold spots unusually low. The result depends on the "
        "weights (neighbourhood size) and tests are exploratory and multiply tested."
    )
    return LocalResult(
        name="Getis-Ord Gi*", table=table, alpha=alpha, p_adjust=p_adjust,
        permutations=permutations, seed=seed, summary=summary,
        interpretation=interpretation, warnings=tuple(notes),
    )
