"""Shared helpers for spatial autocorrelation statistics (NumPy/SciPy only).

Design notes
------------
* PySAL's ``esda`` reports some p-values one-sided and others two-sided depending on the
  statistic and version. To keep results unambiguous this package recomputes every
  p-value from the statistic's z-score or from the retained permutation draws, and always
  reports **two-sided** values.
* ``esda`` draws permutations from NumPy's global random state (and, in newer versions,
  an optional ``seed`` argument). :func:`call_esda` sets both so results are reproducible.
"""

from __future__ import annotations

import inspect
from collections.abc import Iterator, Sequence
from contextlib import contextmanager
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy.stats import norm

QUADRANT_LABELS = {1: "High-High", 2: "Low-High", 3: "Low-Low", 4: "High-Low"}
NOT_SIGNIFICANT = "Not significant"
P_ADJUST_METHODS = ("none", "bonferroni", "fdr_bh")


class StatisticsError(ValueError):
    """Raised for invalid inputs to a spatial statistic."""


@contextmanager
def seeded(seed: int | None) -> Iterator[None]:
    """Temporarily seed NumPy's global RNG, restoring the previous state afterwards."""
    state = np.random.get_state()
    try:
        if seed is not None:
            np.random.seed(seed)
        yield
    finally:
        np.random.set_state(state)


def call_esda(cls, *args, seed: int | None = None, **kwargs):
    """Instantiate an ``esda`` statistic reproducibly and single-threaded.

    ``seed`` / ``n_jobs`` are forwarded only when the installed ``esda`` accepts them.
    """
    params = inspect.signature(cls.__init__).parameters
    if seed is not None and "seed" in params:
        kwargs["seed"] = seed
    if "n_jobs" in params:
        kwargs["n_jobs"] = 1
    with seeded(seed):
        return cls(*args, **kwargs)


def check_alpha(alpha: float) -> None:
    if not 0.0 < alpha < 1.0:
        raise StatisticsError("`alpha` must lie strictly between 0 and 1.")


def prepare_variable(y, n: int, *, name: str = "y", nonnegative: bool = False) -> np.ndarray:
    """Validate an analysis variable and return it as a 1-D float array."""
    arr = np.asarray(y, dtype=float).ravel()
    if arr.size != n:
        raise StatisticsError(f"`{name}` has {arr.size} values but the weights cover {n}.")
    if not np.isfinite(arr).all():
        raise StatisticsError(f"`{name}` contains missing or infinite values; clean it first.")
    if np.ptp(arr) == 0:
        raise StatisticsError(f"`{name}` is constant; spatial autocorrelation is undefined.")
    if nonnegative and (arr < 0).any():
        raise StatisticsError(
            f"`{name}` has negative values; Getis-Ord statistics assume a non-negative "
            "(ratio-scale) variable."
        )
    return arr


def p_from_z(z) -> np.ndarray | float:
    """Two-sided p-value(s) under the standard normal distribution."""
    return 2.0 * norm.sf(np.abs(z))


def pseudo_p_two_sided(observed, sim) -> np.ndarray | float:
    """Two-sided pseudo p-value from permutation draws.

    ``p = (1 + #{|sim - mean(sim)| >= |observed - mean(sim)|}) / (permutations + 1)``.
    ``sim`` is 1-D (one global statistic) or 2-D with shape ``(n_obs, permutations)``.
    """
    sim = np.asarray(sim, dtype=float)
    obs = np.asarray(observed, dtype=float)
    if sim.ndim == 1:
        center = sim.mean()
        extreme = (np.abs(sim - center) >= abs(float(obs) - center)).sum()
        return float((extreme + 1) / (sim.size + 1))
    center = sim.mean(axis=1, keepdims=True)
    extreme = (np.abs(sim - center) >= np.abs(obs.reshape(-1, 1) - center)).sum(axis=1)
    return (extreme + 1) / (sim.shape[1] + 1)


def adjust_pvalues(p: Sequence[float] | np.ndarray, method: str = "none") -> np.ndarray:
    """Multiple-testing adjustment: ``none``, ``bonferroni`` or ``fdr_bh`` (Benjamini-Hochberg)."""
    if method not in P_ADJUST_METHODS:
        raise StatisticsError(f"Unknown p-value adjustment '{method}'. Use {P_ADJUST_METHODS}.")
    p = np.asarray(p, dtype=float)
    m = p.size
    if method == "none" or m == 0:
        return p.copy()
    if method == "bonferroni":
        return np.minimum(p * m, 1.0)
    order = np.argsort(p)
    scaled = p[order] * m / np.arange(1, m + 1)
    monotone = np.minimum.accumulate(scaled[::-1])[::-1]
    out = np.empty(m)
    out[order] = np.minimum(monotone, 1.0)
    return out


def quadrant_codes(z: np.ndarray, lag_z: np.ndarray) -> np.ndarray:
    """Moran scatterplot quadrants: 1 HH, 2 LH, 3 LL, 4 HL (same convention as ``esda``)."""
    high, lag_high = z > 0, lag_z > 0
    return (
        1 * (high & lag_high) + 2 * (~high & lag_high) + 3 * (~high & ~lag_high)
        + 4 * (high & ~lag_high)
    )


def classify_quadrants(quadrants: np.ndarray, p_values: np.ndarray, alpha: float) -> np.ndarray:
    """Label observations by quadrant where significant, else ``"Not significant"``."""
    names = np.array([QUADRANT_LABELS[int(q)] for q in quadrants], dtype=object)
    return np.where(np.asarray(p_values) < alpha, names, NOT_SIGNIFICANT)


def collect_warnings(
    w, n: int, permutations: int, *, local: bool = False
) -> tuple[str, ...]:
    """Caveats worth surfacing next to a result."""
    notes = []
    islands = list(getattr(w, "islands", []))
    if islands:
        notes.append(
            f"{len(islands)} island(s) have no neighbours; they contribute no spatial "
            "information. Consider dropping them."
        )
    if n < 30:
        notes.append("Fewer than 30 observations: asymptotic (normal) inference is unreliable.")
    if 0 < permutations < 99:
        notes.append(
            f"Only {permutations} permutations: the smallest attainable pseudo p-value is "
            f"{1 / (permutations + 1):.3f}. Use 999 or more."
        )
    if local:
        notes.append(
            "Many local tests are run at once and are not independent; consider an "
            "FDR or Bonferroni adjustment."
        )
    return tuple(notes)


@dataclass(frozen=True)
class GlobalResult:
    """Result of a global spatial autocorrelation test."""

    name: str
    symbol: str
    statistic: float
    expected: float
    variance_normal: float
    variance_randomization: float
    z_normal: float
    z_randomization: float
    p_normal: float
    p_randomization: float
    p_sim: float | None
    z_sim: float | None
    permutations: int
    seed: int | None
    alpha: float
    inference: str
    p_value: float
    significant: bool
    direction: str
    interpretation: str
    warnings: tuple[str, ...] = field(default_factory=tuple)

    def to_frame(self) -> pd.DataFrame:
        rows = {
            f"{self.name} {self.symbol}": self.statistic,
            "Expected value": self.expected,
            "Variance (normality)": self.variance_normal,
            "Variance (randomization)": self.variance_randomization,
            "z-score (normality)": self.z_normal,
            "z-score (randomization)": self.z_randomization,
            "p-value (normality, two-sided)": self.p_normal,
            "p-value (randomization, two-sided)": self.p_randomization,
            "Pseudo p-value (permutation, two-sided)": self.p_sim,
            "z-score (permutation)": self.z_sim,
            "Permutations": self.permutations,
            "Seed": self.seed,
        }
        return pd.DataFrame({"value": rows})


@dataclass
class LocalResult:
    """Result of a local (per-observation) spatial statistic."""

    name: str
    table: pd.DataFrame
    alpha: float
    p_adjust: str
    permutations: int
    seed: int | None
    summary: dict[str, int]
    interpretation: str
    warnings: tuple[str, ...] = field(default_factory=tuple)


def decide_global(
    *,
    name: str,
    symbol: str,
    statistic: float,
    expected: float,
    p_normal: float,
    p_sim: float | None,
    permutations: int,
    alpha: float,
    positive_if_above: bool,
) -> tuple[str, float, bool, str, str]:
    """Pick the inference basis and build the plain-language interpretation.

    Returns ``(inference, p_value, significant, direction, interpretation)``.
    """
    use_sim = permutations > 0 and p_sim is not None
    inference = "permutation" if use_sim else "normal approximation"
    p_value = float(p_sim) if use_sim else float(p_normal)
    significant = p_value < alpha
    above = statistic > expected
    if not significant:
        direction = "none"
    elif above == positive_if_above:
        direction = "positive"
    else:
        direction = "negative"

    basis = (
        f"pseudo p-value {p_value:.4f} ({permutations} permutations)"
        if use_sim
        else f"p-value {p_value:.4f} (normal approximation)"
    )
    text = [
        f"{name} {symbol} = {statistic:.4f} (expected {expected:.4f} under spatial randomness)."
    ]
    if direction == "none":
        text.append(
            f"The {basis} is not below alpha = {alpha}, so there is no statistically "
            "significant spatial autocorrelation."
        )
    elif direction == "positive":
        text.append(
            f"The {basis} is below alpha = {alpha}: significant positive spatial "
            "autocorrelation, meaning similar values tend to occur near each other (clustering)."
        )
    else:
        text.append(
            f"The {basis} is below alpha = {alpha}: significant negative spatial "
            "autocorrelation, meaning neighbouring values tend to differ (dispersion)."
        )
    text.append(
        "Significance is not the same as importance: with many observations even weak "
        "autocorrelation is significant, and results depend on the chosen weights. Judge the "
        "size of the statistic and inspect the Moran scatterplot or maps."
    )
    return inference, p_value, significant, direction, " ".join(text)
