"""Spatial weights construction (Queen, Rook, KNN, distance band) with explicit island handling.

Conventions
-----------
* Weights are built on the *positional* order of the GeoDataFrame (``reset_index``), so
  weight id ``i`` is always row ``i``. This alignment is checked before any statistic
  or model is computed.
* ``transform="R"`` row-standardises (each row sums to 1; islands stay all-zero);
  ``transform="B"`` yields binary 0/1 weights. Inverse-distance weights are therefore only
  retained with ``transform="R"``.
* KNN weights are generally asymmetric. Distance weights are symmetric.
* Distance-based kinds need a projected CRS so that distances are in metres/feet, not degrees.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass

import geopandas as gpd
import numpy as np
from libpysal.weights import KNN, DistanceBand, Queen, Rook, W
from scipy.spatial import cKDTree

WEIGHT_KINDS = ("queen", "rook", "knn", "distance")
TRANSFORMS = ("R", "B")


class WeightsError(ValueError):
    """Raised when spatial weights cannot be built or are inconsistent with the data."""


@dataclass(frozen=True)
class WeightsConfig:
    """Specification of a spatial weights matrix.

    kind : ``queen``, ``rook`` (polygons only), ``knn`` or ``distance`` (centroids).
    k : number of neighbours for ``knn``.
    threshold : distance cut-off for ``distance`` in CRS units; ``None`` selects the
        smallest threshold that leaves no island (see :func:`suggest_distance_threshold`).
    binary : for ``distance``; ``False`` uses inverse-distance weights ``d ** alpha``.
    alpha : distance-decay exponent (negative), used when ``binary`` is ``False``.
    transform : ``"R"`` row-standardised (default) or ``"B"`` binary.
    allow_geographic : permit distance/KNN weights on a geographic (degree) CRS.
    """

    kind: str = "queen"
    k: int = 4
    threshold: float | None = None
    binary: bool = True
    alpha: float = -1.0
    transform: str = "R"
    allow_geographic: bool = False

    def __post_init__(self) -> None:
        if self.kind not in WEIGHT_KINDS:
            raise WeightsError(f"Unknown weights kind '{self.kind}'. Use one of {WEIGHT_KINDS}.")
        if self.transform not in TRANSFORMS:
            raise WeightsError(f"Unknown transform '{self.transform}'. Use one of {TRANSFORMS}.")
        if self.k < 1:
            raise WeightsError("`k` must be at least 1.")
        if self.threshold is not None and self.threshold <= 0:
            raise WeightsError("`threshold` must be positive.")
        if self.alpha >= 0:
            raise WeightsError("`alpha` must be negative (distance decay).")

    def describe(self) -> str:
        std = "row-standardised" if self.transform == "R" else "binary"
        if self.kind in {"queen", "rook"}:
            return f"{self.kind.capitalize()} contiguity, {std}"
        if self.kind == "knn":
            return f"{self.k} nearest neighbours, {std}"
        thr = "auto threshold" if self.threshold is None else f"threshold {self.threshold:g}"
        kernel = "binary" if self.binary else f"inverse-distance (alpha={self.alpha:g})"
        return f"Distance band ({thr}, {kernel}), {std}"


def _centroid_coords(gdf: gpd.GeoDataFrame) -> np.ndarray:
    geoms = gdf.geometry
    if geoms.isna().any() or geoms.is_empty.any():
        raise WeightsError("Null or empty geometries found; run preprocessing first.")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")  # centroid-in-geographic-CRS warning
        cent = geoms.centroid
    return np.column_stack([cent.x.to_numpy(), cent.y.to_numpy()])


def suggest_distance_threshold(gdf: gpd.GeoDataFrame) -> float:
    """Smallest distance band that gives every observation at least one neighbour
    (the largest nearest-neighbour distance between centroids)."""
    if len(gdf) < 2:
        raise WeightsError("At least two observations are required.")
    coords = _centroid_coords(gdf.reset_index(drop=True))
    dist, _ = cKDTree(coords).query(coords, k=2)
    return float(dist[:, 1].max() * (1 + 1e-9))


def build_weights(
    gdf: gpd.GeoDataFrame, config: WeightsConfig | None = None, **kwargs
) -> W:
    """Build a :class:`libpysal.weights.W` for ``gdf`` from a config (or keyword arguments).

    Islands are *not* removed here: inspect them with
    :func:`spatial_econometrics.weights.diagnostics.weights_summary`, or use
    :func:`build_weights_without_islands`.
    """
    if config is not None and kwargs:
        raise WeightsError("Pass either `config` or keyword arguments, not both.")
    cfg = config or WeightsConfig(**kwargs)
    n = len(gdf)
    if n < 2:
        raise WeightsError("At least two observations are required.")
    data = gdf.reset_index(drop=True)

    if cfg.kind in {"queen", "rook"}:
        if not set(data.geometry.geom_type.dropna().unique()) <= {"Polygon", "MultiPolygon"}:
            raise WeightsError(
                f"{cfg.kind.capitalize()} contiguity needs polygon geometries. "
                "Use KNN or distance weights for points."
            )
        cls = Queen if cfg.kind == "queen" else Rook
        build = lambda: cls.from_dataframe(data)  # noqa: E731
    else:
        if data.crs is not None and data.crs.is_geographic and not cfg.allow_geographic:
            raise WeightsError(
                "Distance-based weights need a projected CRS (units of metres/feet). "
                "Reproject the data, or set `allow_geographic=True` to accept distortion."
            )
        _centroid_coords(data)  # validates geometries
        if cfg.kind == "knn":
            if cfg.k >= n:
                raise WeightsError(f"`k` ({cfg.k}) must be smaller than the number of rows ({n}).")
            build = lambda: KNN.from_dataframe(data, k=cfg.k)  # noqa: E731
        else:
            threshold = cfg.threshold or suggest_distance_threshold(data)
            build = lambda: DistanceBand.from_dataframe(  # noqa: E731
                data, threshold=threshold, binary=cfg.binary, alpha=cfg.alpha
            )

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")  # libpysal island / deprecation chatter
        w = build()
        w.transform = cfg.transform
    if w.n != n:
        raise WeightsError(f"Weights cover {w.n} observations but the data has {n}.")
    return w


def build_weights_without_islands(
    gdf: gpd.GeoDataFrame, config: WeightsConfig, *, max_iter: int = 10
) -> tuple[gpd.GeoDataFrame, W, list[int]]:
    """Iteratively drop islands and rebuild weights until none remain.

    Removing an observation can strand its former neighbours, hence the loop. Returns
    ``(subset, weights, dropped_positions)`` where ``dropped_positions`` are row positions
    in the *input* frame. Report these to the user: dropping observations changes the
    sample.
    """
    data = gdf.reset_index(drop=True)
    keep = np.arange(len(data))
    dropped: list[int] = []
    for _ in range(max_iter):
        subset = data.iloc[keep].reset_index(drop=True)
        w = build_weights(subset, config)
        islands = [int(i) for i in w.islands]
        if not islands:
            return subset, w, dropped
        dropped.extend(int(p) for p in keep[islands])
        keep = np.delete(keep, islands)
        if len(keep) < 2:
            raise WeightsError("Dropping islands leaves fewer than two observations.")
    raise WeightsError(f"Islands remain after {max_iter} iterations; revise the weights settings.")
