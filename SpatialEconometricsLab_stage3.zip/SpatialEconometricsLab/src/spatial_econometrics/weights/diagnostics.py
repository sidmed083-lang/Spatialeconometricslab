"""Diagnostics and validation for spatial weights."""

from __future__ import annotations

import geopandas as gpd
import numpy as np
import pandas as pd
from libpysal.weights import W
from scipy.sparse.csgraph import connected_components
from shapely.geometry import LineString

from .construction import WeightsError


def _structure(w: W):
    s = w.sparse.tocsr()
    return s


def weights_summary(w: W) -> dict:
    """Connectivity summary: neighbour counts, islands, components, symmetry."""
    s = _structure(w)
    n = s.shape[0]
    card = np.asarray(s.getnnz(axis=1))
    ids = list(w.id_order)
    island_pos = np.flatnonzero(card == 0)
    binary = s.copy()
    binary.data = np.ones_like(binary.data)
    symmetric = abs(binary - binary.T).sum() == 0
    return {
        "n": int(n),
        "n_islands": int(island_pos.size),
        "islands": [ids[i] for i in island_pos],
        "min_neighbors": int(card.min()),
        "max_neighbors": int(card.max()),
        "mean_neighbors": float(card.mean()),
        "median_neighbors": float(np.median(card)),
        "pct_nonzero": float(100.0 * s.nnz / (n * n)),
        "n_components": int(connected_components(s, directed=False)[0]),
        "is_symmetric_structure": bool(symmetric),
        "transform": str(w.transform),
    }


def cardinality_table(w: W) -> pd.DataFrame:
    """Number of neighbours per observation (positional order)."""
    card = np.asarray(w.sparse.tocsr().getnnz(axis=1))
    return pd.DataFrame({"obs": np.arange(card.size), "n_neighbors": card})


def weights_to_edges(gdf: gpd.GeoDataFrame, w: W) -> gpd.GeoDataFrame:
    """Undirected connections as LineStrings between geometry centroids (for maps).

    Directed (asymmetric) links such as KNN are collapsed to one line per pair.
    """
    validate_weights(w, len(gdf))
    data = gdf.reset_index(drop=True)
    cent = data.geometry.centroid
    coo = w.sparse.tocoo()
    pairs = sorted({(int(min(i, j)), int(max(i, j))) for i, j in zip(coo.row, coo.col) if i != j})
    lines = [LineString([cent.iloc[i], cent.iloc[j]]) for i, j in pairs]
    return gpd.GeoDataFrame(
        {"i": [p[0] for p in pairs], "j": [p[1] for p in pairs]}, geometry=lines, crs=data.crs
    )


def validate_weights(w: W, n: int) -> None:
    """Check dimensions, id alignment and weight values before computing statistics."""
    if w.n != n:
        raise WeightsError(f"Weights cover {w.n} observations but the data has {n}.")
    if list(w.id_order) != list(range(n)):
        raise WeightsError(
            "Weight ids are not 0..n-1 in row order; rebuild weights from the current data."
        )
    data = w.sparse.data
    if not np.isfinite(data).all():
        raise WeightsError("Weights contain NaN or infinite values.")
    if (data < 0).any():
        raise WeightsError("Weights contain negative values.")


def require_no_islands(w: W) -> None:
    """Raise if any observation has no neighbours (required before model estimation)."""
    islands = list(w.islands)
    if islands:
        shown = ", ".join(str(i) for i in islands[:10]) + ("..." if len(islands) > 10 else "")
        raise WeightsError(
            f"{len(islands)} island(s) with no neighbours (rows: {shown}). Drop them with "
            "`build_weights_without_islands` or choose a different weights definition."
        )
