"""Spatial weights construction and diagnostics."""

from .construction import (
    WEIGHT_KINDS,
    WeightsConfig,
    WeightsError,
    build_weights,
    build_weights_without_islands,
    suggest_distance_threshold,
)
from .diagnostics import (
    cardinality_table,
    require_no_islands,
    validate_weights,
    weights_summary,
    weights_to_edges,
)

__all__ = [
    "WEIGHT_KINDS",
    "WeightsConfig",
    "WeightsError",
    "build_weights",
    "build_weights_without_islands",
    "cardinality_table",
    "require_no_islands",
    "suggest_distance_threshold",
    "validate_weights",
    "weights_summary",
    "weights_to_edges",
]
